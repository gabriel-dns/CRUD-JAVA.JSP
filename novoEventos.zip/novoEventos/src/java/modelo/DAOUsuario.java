/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Gabriel Nascimento
 */
public class DAOUsuario {
    
    
    
    
     public List<Usuario> consultar(){
        String sql = "select * from usuario";
        List<Usuario> listaUsuario = new ArrayList<>();
        
        try{
            
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            
            while(rs.next()){
                Usuario usuario = new Usuario();
               
                 usuario.setLogin(rs.getInt("login"));
                 usuario.setSenha(rs.getInt("senha"));
                 usuario.setNick(rs.getString("nick"));
                 usuario.setId(rs.getInt("idUsuario"));
                 
                 
                listaUsuario.add(usuario);
               
            }
                rs.close();
                stmt.close();
        }catch(SQLException ex){
            System.out.println("Erro no consultar do DAOUsuario. java "+ex);
            
        }
        
        
        return listaUsuario;
    
}
    
    public String inserir(Usuario usuario){
        String mensagem="";
        String sql ="insert into usuario(login,senha,nick) values(?,?,?)";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, usuario.getLogin());
            stmt.setInt(2, usuario.getSenha());
            stmt.setString(3, usuario.getNick());
            
            
            
            if(stmt.executeUpdate()>0){
                mensagem = "Usuario cadastrado com sucesso";          
            }else{
                mensagem = "Usuario não cadastrado";
            }
            stmt.close();
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
    
     public String alterar(Usuario usuario){
        String mensagem="";
        String sql ="update usuario set login=?,senha=?,nick=? where idUsuario=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, usuario.getLogin());
            stmt.setInt(2, usuario.getSenha());
            stmt.setString(3, usuario.getNick());
            stmt.setInt(4, usuario.getIdUsuario());
            
            if(stmt.executeUpdate()>0){
                mensagem = "Usuario alterado com sucesso";          
            }else{
                mensagem = "Usuario não alterado";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
     
      public String excluir(Usuario usuario){
        String mensagem="";
        String sql ="delete from usuario where idUsuario=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, usuario.getIdUsuario());
            if(stmt.executeUpdate()>0){
                mensagem = "Usuario excluido com sucesso";          
            }else{
                mensagem = "Usuario não excluido";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
    
    
}
