/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
/**
 *
 * @author Gabriel Nascimento
 */
public class DAOEvento {
          
    public List<Evento> consultar(){
        String sql = "select * from evento";
        List<Evento> listaEvento = new ArrayList<>();
        
        try{
            
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            
            while(rs.next()){
                Evento evento = new Evento();
               
                evento.setNome(rs.getString("nome"));
                evento.setTipo(rs.getString("tipo"));
                evento.setBanda(rs.getString("cantorBanda"));
                evento.setData(rs.getString("data")); 
                evento.setId(rs.getInt("id"));
                listaEvento.add(evento);
               
            }
                rs.close();
                stmt.close();
        }catch(SQLException ex){
            System.out.println("Erro no consultar do DAOEvento. java "+ex);
            
        }
        
        
        return listaEvento;
    
}
    
    public String inserir(Evento evento){
        String mensagem="";
        String sql ="insert into evento(nome,data,tipo,cantorBanda) values(?,?,?,?)";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setString(1, evento.getNome());
            stmt.setString(2, evento.getData());
            stmt.setString(3, evento.getTipo());
            stmt.setString(4, evento.getBanda());
            
            
            if(stmt.executeUpdate()>0){
                mensagem = "Evento cadastrado com sucesso";          
            }else{
                mensagem = "Evento não cadastrado";
            }
            stmt.close();
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
    
     public String alterar(Evento evento){
        String mensagem="";
        String sql ="update evento set nome=?, data=?,tipo=?,cantorBanda=? where id =?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setString(1, evento.getNome());
            stmt.setString(2, evento.getData());
            stmt.setString(3, evento.getTipo());
            stmt.setString(4, evento.getBanda());
            stmt.setInt(5, evento.getId());
            
            if(stmt.executeUpdate()>0){
                mensagem = "Evento alterado com sucesso";          
            }else{
                mensagem = "Evento não alterado";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
     
      public String excluir(Evento evento){
        String mensagem="";
        String sql ="delete from evento where id=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, evento.getId());
            if(stmt.executeUpdate()>0){
                mensagem = "Evento excluido com sucesso";          
            }else{
                mensagem = "Evento não excluido";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
      
      
        public Evento localizar(Integer id) {
        String sql = "select * from evento where id=?";
        Evento evento = new Evento();
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
               evento.setNome(rs.getString("nome"));
               evento.setTipo(rs.getString("tipo"));
               evento.setBanda(rs.getString("cantorBanda"));
               evento.setData(rs.getString("data")); 
               evento.setId(rs.getInt("id"));
                return evento;
            }
        } catch (SQLException erro) {
            System.out.println("Erro no localizar do DAOEvento"
                    +erro.getMessage() + "\nComando SQL = " + sql);
        }
        return null;
    }
    
}
