package modelo;




public class VendaItensServico {
    
    private Integer id;
    private VendaServico vendaServico = new VendaServico();
    private Servico idServico = new Servico();
    private Double valor;
    private Integer qtd;

    public VendaServico getVendaServico() {
        return vendaServico;
    }

    public void setVendaServico(VendaServico vendaServico) {
        this.vendaServico = vendaServico;
    }
    
    
    public Integer getQtd() {
        return qtd;
    }

    public void setQtd(Integer qtd) {
        this.qtd = qtd;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Servico getIdServico() {
        return idServico;
    }

    public void setIdServico(Servico idServico) {
        this.idServico = idServico;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }
    
    
    
}
