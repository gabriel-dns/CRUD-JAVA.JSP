/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Gabriel Nascimento
 */
public class DAOFornecedor {
     public List<Fornecedor> consultar(){
        String sql = "select * from fornecedor";
        List<Fornecedor> listaFornecedor = new ArrayList<>();
        
        try{
            
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            
            while(rs.next()){
                Fornecedor fornecedor = new Fornecedor();
               
                 fornecedor.setNomeEmpresa(rs.getString("nomeEmpresa"));
                 fornecedor.setTipo(rs.getString("tipo"));
                 fornecedor.setIdFornecedor(rs.getInt("idFornecedor"));
                 
                 
                listaFornecedor.add(fornecedor);
               
            }
                rs.close();
                stmt.close();
        }catch(SQLException ex){
            System.out.println("Erro no consultar do DAOFornecedor. java "+ex);
            
        }
        
        
        return listaFornecedor;
    
}
    
    public String inserir(Fornecedor fornecedor){
        String mensagem="";
        String sql ="insert into fornecedor(nomeEmpresa,tipo) values(?,?)";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setString(1, fornecedor.getNomeEmpresa());
            stmt.setString(2, fornecedor.getTipo());
            
            
            
            if(stmt.executeUpdate()>0){
                mensagem = "Fornecedor cadastrado com sucesso";          
            }else{
                mensagem = "Fornecedor não cadastrado";
            }
            stmt.close();
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
    
     public String alterar(Fornecedor fornecedor){
        String mensagem="";
        String sql ="update fornecedor set nomeEmpresa=?, tipo=? where  idFornecedor=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setString(1, fornecedor.getNomeEmpresa());
            stmt.setString(2, fornecedor.getTipo());
            stmt.setInt(3, fornecedor.getIdFornecedor());
            
            if(stmt.executeUpdate()>0){
                mensagem = "Fornecedor alterado com sucesso";          
            }else{
                mensagem = "Fornecedor não alterado";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
     
      public String excluir(Fornecedor fornecedor){
        String mensagem="";
        String sql ="delete from fornecedor where idFornecedor=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, fornecedor.getIdFornecedor());
            if(stmt.executeUpdate()>0){
                mensagem = "Fornecedor excluido com sucesso";          
            }else{
                mensagem = "Fornecedor não excluido";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
      
      
       public Fornecedor localizar(Integer id) {
        String sql = "select * from evento where idFornecedor=?";
        Fornecedor fornecedor = new Fornecedor();
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
              
                 fornecedor.setNomeEmpresa(rs.getString("nomeEmpresa"));
                 fornecedor.setTipo(rs.getString("tipo"));
                 fornecedor.setIdFornecedor(rs.getInt("idFornecedor"));
                return fornecedor;
            }
        } catch (SQLException erro) {
            System.out.println("Erro no localizar do DAOfornecedor"
                    +erro.getMessage() + "\nComando SQL = " + sql);
        }
        return null;
    }
    
}
