package modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class DAOVendaItensProduto {
  
    
    
    DAOVendaProduto daoV = new DAOVendaProduto();
    DAOProduto daoP = new DAOProduto();
   ConverteData converte = new ConverteData();
   
   
   
   public List<VendaItensProduto> getLista(Integer id){
        String sql = "select * from vendaitensproduto where vendaProduto=?";
        List<VendaItensProduto> lista = new ArrayList<>();
        try{
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
              VendaItensServico vendaitensservico = new VendaItensServico();
               
                 VendaItensProduto vendaitensproduto = new VendaItensProduto();
                
                 vendaitensproduto.setVendaProduto(daoV.localizar(rs.getInt("vendaProduto")));
                 vendaitensproduto.setValor(rs.getDouble("valor"));
                 vendaitensproduto.setQtd(rs.getInt("qtd"));
                 vendaitensproduto.setIdProduto(daoP.localizar(rs.getInt("idProduto")));
                 vendaitensproduto.setId(rs.getInt("id"));
                lista.add(vendaitensproduto);
            }
            rs.close();
            pst.close();
        }catch(SQLException e){
            System.out.println("Erro de SQL DAO Itens Produto getLista(): "+e.getMessage());
        }
        return lista;
    }
    /*
     public List<VendaItensProduto> consultar(){
        String sql = "select * from vendaitensproduto";
        List<VendaItensProduto> listaItensVenda = new ArrayList<>();
        
        try{
            
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            
            while(rs.next()){
                VendaItensProduto vendaitensproduto = new VendaItensProduto();
               
                 vendaitensproduto.setVendaProduto(daoV.localizar(rs.getInt("vendaProduto")));
                 vendaitensproduto.setValor(rs.getDouble("valor"));
                 vendaitensproduto.setQtd(rs.getInt("qtd"));
                 vendaitensproduto.setIdProduto(daoP.localizar(rs.getInt("idProduto")));
                 vendaitensproduto.setId(rs.getInt("id"));
                 
                 
                listaItensVenda.add(vendaitensproduto);
               
            }
                rs.close();
                stmt.close();
        }catch(SQLException ex){
            System.out.println("Erro no consultar do DAOItensVenda. java "+ex);
          
            
        }
        
        
        return listaItensVenda;
    
}
*/
    
  
    public String inserir(VendaItensProduto vendaitensproduto){
        String mensagem="";
        String sql ="insert into vendaitensproduto(vendaProduto,idProduto,valor,qtd) values(?,?,?,?)";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, vendaitensproduto.getVendaProduto().getId());
            stmt.setInt(2, vendaitensproduto.getIdProduto().getId());
            stmt.setDouble(3, vendaitensproduto.getValor());
            stmt.setInt(4, vendaitensproduto.getQtd());
            
            
            
            
            
            if(stmt.executeUpdate()>0){
                mensagem = "ItensVenda cadastrado com sucesso";          
            }else{
                mensagem = "ItensVenda não cadastrado";
            }
            stmt.close();
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
    
     public String alterar(VendaItensProduto vendaitensproduto){
        String mensagem="";
        String sql ="update vendaitensproduto set vendaProduto=?,idProduto=?,valor=?,qtd=? where id=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, vendaitensproduto.getVendaProduto().getId());
            stmt.setInt(2, vendaitensproduto.getIdProduto().getId());
            stmt.setDouble(3, vendaitensproduto.getValor());
            stmt.setInt(4, vendaitensproduto.getQtd());
            stmt.setInt(5, vendaitensproduto.getId());
            
            if(stmt.executeUpdate()>0){
                mensagem = "ItensVenda alterado com sucesso";          
            }else{
                mensagem = "ItensVenda não alterado";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
     
      public String excluir(VendaItensProduto vendaitensproduto){
        String mensagem="";
        String sql ="delete from vendaitensproduto where id=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, vendaitensproduto.getId());
            if(stmt.executeUpdate()>0){
                mensagem = "ItensVenda excluido com sucesso";          
            }else{
                mensagem = "ItensVenda não excluido";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
    
    
}
