/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author Gabriel Nascimento
 */
public class DAOServico {
    
    DAOFornecedor dao = new DAOFornecedor();
    
     public List<Servico> consultar(){
        String sql = "select * from servico";
        List<Servico> listaServico = new ArrayList<>();
        
        try{
            
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            
            while(rs.next()){
                Servico servico = new Servico();
               
                 servico.setValor(rs.getDouble("valor"));
                 servico.setTipo(rs.getString("tipo"));
                 servico.setServicopFornecedor(dao.localizar(rs.getInt("servicopFornecedor")));
                 servico.setId(rs.getInt("id"));
                 
                 
                listaServico.add(servico);
               
            }
                rs.close();
                stmt.close();
        }catch(SQLException ex){
            System.out.println("Erro no consultar do DAOServico. java "+ex);
            
        }
        
        
        return listaServico;
    
}
    
    public String inserir(Servico servico){
        String mensagem="";
        String sql ="insert into servico(servicopFornecedor,valor,tipo) values(?,?,?)";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, servico.getServicopFornecedor().getIdFornecedor());
            stmt.setDouble(2, servico.getValor());
            stmt.setString(3, servico.getTipo());
            
            
            if(stmt.executeUpdate()>0){
                mensagem = "Servico cadastrado com sucesso";          
            }else{
                mensagem = "Servico não cadastrado";
            }
            stmt.close();
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
    
     public String alterar(Servico servico){
        String mensagem="";
        String sql ="update servico set servicopFornecedor=?, valor=?, tipo=? where  id=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, servico.getServicopFornecedor().getIdFornecedor());
            stmt.setDouble(2, servico.getValor());
            stmt.setString(3, servico.getTipo());
            stmt.setInt(4, servico.getId());
            
            if(stmt.executeUpdate()>0){
                mensagem = "Servico alterado com sucesso";          
            }else{
                mensagem = "Servico não alterado";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
     
      public String excluir(Servico servico){
        String mensagem="";
        String sql ="delete from servico where id=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, servico.getId());
            if(stmt.executeUpdate()>0){
                mensagem = "Servico excluido com sucesso";          
            }else{
                mensagem = "Servico não excluido";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
      
       
       public Servico localizar(Integer id){
        String sql="select * from servico where id=?";
        Servico servico = new Servico();
           try{
               PreparedStatement pst = Conexao.getPreparedStatement(sql);
               pst.setInt(1, id);
               ResultSet rs = pst.executeQuery();
               while(rs.next()){
                
                 servico.setValor(rs.getDouble("valor"));
                 servico.setTipo(rs.getString("tipo"));
                 servico.setServicopFornecedor(dao.localizar(rs.getInt("servicopFornecedor")));
                 servico.setId(rs.getInt("id"));
                 
                   return servico;
           }
    } catch(SQLException erro){
               System.out.println("Erro no localizar do DAOServico"+ erro.getMessage() + "\n Comando sql = " + sql);
    }
    
    return null;
    
}
}
