/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Gabriel Nascimento
 */
public class DAOCliente {
       
    public List<Cliente> consultar(){
        String sql = "select * from cliente";
        List<Cliente> listaCliente = new ArrayList<>();
        
        try{
            
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            
            while(rs.next()){
                Cliente cliente = new Cliente();
               
                 cliente.setNome(rs.getString("nome"));
                 cliente.setPedido(rs.getString("pedido"));
                 cliente.setCpf(rs.getString("cpf"));
                 cliente.setEmail(rs.getString("email"));
                 cliente.setEndereco(rs.getString("endereco"));
                 cliente.setTelefone(rs.getString("telefone"));
                 cliente.setId(rs.getInt("id"));
                 
                 
                listaCliente.add(cliente);
               
            }
                rs.close();
                stmt.close();
        }catch(SQLException ex){
            System.out.println("Erro no consultar do DAOCliente. java "+ex);
            
        }
        
        
        return listaCliente;
    
}
    
    public String inserir(Cliente cliente){
        String mensagem="";
        String sql ="insert into cliente(nome,pedido,cpf,email,telefone,endereco) values(?,?,?,?,?,?)";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setString(1, cliente.getNome());
            stmt.setString(2, cliente.getPedido());
            stmt.setString(3, cliente.getCpf());
            stmt.setString(4, cliente.getEmail());
            stmt.setString(5, cliente.getTelefone());
            stmt.setString(6, cliente.getEndereco());
            
            
            if(stmt.executeUpdate()>0){
                mensagem = "Cliente cadastrado com sucesso";          
            }else{
                mensagem = "Cliente não cadastrado";
            }
            stmt.close();
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
    
     public String alterar(Cliente cliente){
        String mensagem="";
        String sql ="update cliente set nome=?, pedido=?,cpf=?,email=?, telefone=?, endereco=? where id=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setString(1, cliente.getNome());
            stmt.setString(2, cliente.getPedido());
            stmt.setString(3, cliente.getCpf());
            stmt.setString(4, cliente.getEmail());
            stmt.setString(5, cliente.getTelefone());
            stmt.setString(6, cliente.getEndereco());
            stmt.setInt(7, cliente.getId());
            
            if(stmt.executeUpdate()>0){
                mensagem = "Cliente alterado com sucesso";          
            }else{
                mensagem = "Cliente não alterado";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
     
      public String excluir(Cliente cliente){
        String mensagem="";
        String sql ="delete from cliente where id=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, cliente.getId());
            if(stmt.executeUpdate()>0){
                mensagem = "Cliente excluido com sucesso";          
            }else{
                mensagem = "Cliente não excluido";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
      
        public Cliente localizar(Integer id){
        String sql="select * from cliente where id=?";
        Cliente cliente = new Cliente();
           try{
               PreparedStatement pst = Conexao.getPreparedStatement(sql);
               pst.setInt(1, id);
               ResultSet rs = pst.executeQuery();
               while(rs.next()){
               
                 cliente.setNome(rs.getString("nome"));
                 cliente.setPedido(rs.getString("pedido"));
                 cliente.setCpf(rs.getString("cpf"));
                 cliente.setEmail(rs.getString("email"));
                 cliente.setEndereco(rs.getString("endereco"));
                 cliente.setId(rs.getInt("id"));
                 
                   return cliente;
           }
    } catch(SQLException erro){
               System.out.println("Erro no localizar do DAOV"+ erro.getMessage() + "\n Comando sql = " + sql);
    }
    
    return null;
    
}
    
    
}
