/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 *
 * @author Gabriel Nascimento
 */
public class DAOFuncionario {
    public List<Funcionario> consultar(){
        String sql = "select * from funcionario";
        List<Funcionario> listaFuncionario = new ArrayList<>();
        
        try{
            
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            
            while(rs.next()){
                Funcionario funcionario = new Funcionario();
               
                 funcionario.setNome(rs.getString("nome"));
                 funcionario.setSalario(rs.getDouble("salario"));
                 funcionario.setDataAdmissao(rs.getString("dataAdmissao"));
                 funcionario.setNascimento(rs.getString("nascimento"));
                 funcionario.setTelefone(rs.getString("telefone"));
                 funcionario.setEndereco(rs.getString("endereco"));
                 funcionario.setFuncao(rs.getString("funcao"));
                 funcionario.setIdFuncionario(rs.getInt("idFuncionario"));
                 
                 
                listaFuncionario.add(funcionario);
               
            }
                rs.close();
                stmt.close();
        }catch(SQLException ex){
            System.out.println("Erro no consultar do DAOFuncionario. java "+ex);
            
        }
        
        
        return listaFuncionario;
    
}
    
    public String inserir(Funcionario funcionario){
        String mensagem="";
        String sql ="insert into funcionario(nome,salario,dataAdmissao,endereco,nascimento,telefone,funcao) values(?,?,?,?,?,?,?)";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setString(1, funcionario.getNome());
            stmt.setDouble(2, funcionario.getSalario());
            stmt.setString(3, funcionario.getDataAdmissao());
            stmt.setString(4, funcionario.getEndereco());
            stmt.setString(5, funcionario.getNascimento());
            stmt.setString(6, funcionario.getTelefone());
            stmt.setString(7, funcionario.getFuncao());
            
            
            if(stmt.executeUpdate()>0){
                mensagem = "Funcionario cadastrado com sucesso";          
            }else{
                mensagem = "Funcionario não cadastrado";
            }
            stmt.close();
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
    
     public String alterar(Funcionario funcionario){
        String mensagem="";
        String sql ="update funcionario set nome=?, salario=?,dataAdmissao=?, endereco=?, nascimento=?, telefone=?, funcao=? where idFuncionario=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setString(1, funcionario.getNome());
            stmt.setDouble(2, funcionario.getSalario());
            stmt.setString(3, funcionario.getDataAdmissao());
            stmt.setString(4, funcionario.getEndereco());
            stmt.setString(5, funcionario.getNascimento());
            stmt.setString(6, funcionario.getTelefone());
            stmt.setString(7, funcionario.getFuncao());
            stmt.setInt(8, funcionario.getIdFuncionario());
            
            if(stmt.executeUpdate()>0){
                mensagem = "Funcionario alterado com sucesso";          
            }else{
                mensagem = "Funcionario não alterado";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
     
      public String excluir(Funcionario funcionario){
        String mensagem="";
        String sql ="delete from funcionario where idFuncionario=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, funcionario.getIdFuncionario());
            if(stmt.executeUpdate()>0){
                mensagem = "Funcionario excluido com sucesso";          
            }else{
                mensagem = "Funcionario não excluido";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
    
}
