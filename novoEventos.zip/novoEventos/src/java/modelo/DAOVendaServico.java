package modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class DAOVendaServico {
  
    
    
    DAOEvento daoF = new DAOEvento();
    DAOCliente daoC = new DAOCliente();
   ConverteData converte = new ConverteData();
   
    private int lastId;

    public int getLastId() {
        return lastId;
    }
    
     public List<VendaServico> consultar(){
        String sql = "select * from vendaservico";
        List<VendaServico> listaVendaServico = new ArrayList<>();
        
        try{
            
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            
            while(rs.next()){
                VendaServico vendas = new VendaServico();
               
                 vendas.setIdEvento(daoF.localizar(rs.getInt("idEvento")));
                 vendas.setDataVenda(converte.converteCalendario(rs.getDate("dataVenda")));
                 vendas.setIdCliente(daoC.localizar(rs.getInt("idCliente")));
                 vendas.setId(rs.getInt("id"));
                 
                 
                listaVendaServico.add(vendas);
               
            }
                rs.close();
                stmt.close();
        }catch(SQLException ex){
            System.out.println("Erro no consultar do DAOVendaServico. java "+ex);
          
            
        }
        
        
        return listaVendaServico;
    
}
    
  
    public String inserir(VendaServico vendas){
        String mensagem="";
        String sql ="insert into vendaservico(idEvento,dataVenda,idCliente) values(?,?,?)";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, vendas.getIdEvento().getId());
            stmt.setDate(2, converte.converteBanco(vendas.getDataVenda()));
            stmt.setInt(3, vendas.getIdCliente().getId());
            
            
            
           
            if (stmt.executeUpdate() > 0) {
                 ResultSet rs = stmt.getGeneratedKeys();
                if (rs.next()) {
                    lastId = rs.getInt(1);
                }
                mensagem = "Venda cadastrada com sucesso";
            } else {
                mensagem = "Venda não cadastrado!";
            }
            stmt.close();
        } catch (SQLException e) {
            mensagem = e.getMessage();
        }
        return mensagem;
    }
    
     public String alterar(VendaServico vendas){
        String mensagem="";
        String sql ="update vendaservico set idEvento=?,dataVenda=?,idCliente=? where id=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, vendas.getIdEvento().getId());
            stmt.setDate(2, converte.converteBanco(vendas.getDataVenda()));
            stmt.setInt(3, vendas.getIdCliente().getId()); 
            stmt.setInt(4, vendas.getId());
            
            if(stmt.executeUpdate()>0){
                mensagem = "VendaServico alterado com sucesso";          
            }else{
                mensagem = "VendaServico não alterado";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
     
      public String excluir(VendaServico vendas){
        String mensagem="";
        String sql ="delete from vendaservico where id=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, vendas.getId());
            if(stmt.executeUpdate()>0){
                mensagem = "VendaServico excluido com sucesso";          
            }else{
                mensagem = "VendaServico não excluido";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
    
      
      
       public VendaServico localizar(Integer id){
        String sql="select * from vendaservico where id=?";
        VendaServico vendas = new VendaServico();
           try{
               PreparedStatement pst = Conexao.getPreparedStatement(sql);
               pst.setInt(1, id);
               ResultSet rs = pst.executeQuery();
               while(rs.next()){
                
                  vendas.setIdEvento(daoF.localizar(rs.getInt("idEvento")));
                 vendas.setDataVenda(converte.converteCalendario(rs.getDate("dataVenda")));
                 vendas.setIdCliente(daoC.localizar(rs.getInt("idCliente")));
                 vendas.setId(rs.getInt("id"));
                 
                   return vendas;
           }
    } catch(SQLException erro){
               System.out.println("Erro no localizar do DAOVendaServico"+ erro.getMessage() + "\n Comando sql = " + sql);
    }
    return null;
    
}
    
}
