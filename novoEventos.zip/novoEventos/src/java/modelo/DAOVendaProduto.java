package modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class DAOVendaProduto {
    
     DAOEvento daoF = new DAOEvento();
    DAOCliente daoC = new DAOCliente();
      ConverteData converte = new ConverteData();
    private int lastId;

    public int getLastId() {
        return lastId;
    }

    public String incluir(VendaProduto obj) {
        String mensagem;
        String sql = "insert into vendaproduto (idCliente,idEvento,dataVenda) values (?,?,?)";
        try {
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, obj.getIdCliente().getId());
            pst.setInt(2, obj.getIdEvento().getId());
            pst.setDate(3, converte.converteBanco(obj.getDataVenda()));

            if (pst.executeUpdate() > 0) {
                 ResultSet rs = pst.getGeneratedKeys();
                if (rs.next()) {
                    lastId = rs.getInt(1);
                }
                mensagem = "Venda cadastrada com sucesso";
            } else {
                mensagem = "Venda não cadastrado!";
            }
            pst.close();
        } catch (SQLException e) {
            mensagem = e.getMessage();
        }
        return mensagem;
    }
    
    
     public String excluir(VendaProduto vendas){
        String mensagem="";
        String sql ="delete from vendaproduto where id=?";
        try {
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, vendas.getId());
            if (stmt.executeUpdate() > 0) {
                mensagem = "Venda cancelada";
            } else {
                mensagem = "Venda não cancelada";
            }
            stmt.close();
        } catch (SQLException e) {
            mensagem = e.getMessage() + "\nComando SQL = " + sql;

        }
        return mensagem;
    }
    
    
      
      
       public VendaProduto localizar(Integer id){
        String sql="select * from vendaproduto where id=?";
        VendaProduto vendas = new VendaProduto();
           try{
               PreparedStatement pst = Conexao.getPreparedStatement(sql);
               pst.setInt(1, id);
               ResultSet rs = pst.executeQuery();
               while(rs.next()){
                
                vendas.setIdEvento(daoF.localizar(rs.getInt("idEvento")));
                 vendas.setDataVenda(converte.converteCalendario(rs.getDate("dataVenda")));
                 vendas.setIdCliente(daoC.localizar(rs.getInt("idCliente")));
                 vendas.setId(rs.getInt("id"));
                 
                   return vendas;
           }
    } catch(SQLException erro){
               System.out.println("Erro no localizar do DAOVendaProduto"+ erro.getMessage() + "\n Comando sql = " + sql);
    }
    return null;
    
}

    
    
  /*
    
    
    DAOEvento daoF = new DAOEvento();
    DAOCliente daoC = new DAOCliente();
   ConverteData converte = new ConverteData();
    
     public List<VendaProduto> consultar(){
        String sql = "select * from vendaproduto";
        List<VendaProduto> listaVendaProduto = new ArrayList<>();
        
        try{
            
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            
            while(rs.next()){
                VendaProduto vendas = new VendaProduto();
               
                 vendas.setIdEvento(daoF.localizar(rs.getInt("idEvento")));
                 vendas.setDataVenda(converte.converteCalendario(rs.getDate("dataVenda")));
                 vendas.setIdCliente(daoC.localizar(rs.getInt("idCliente")));
                 vendas.setId(rs.getInt("id"));
                 
                 
                listaVendaProduto.add(vendas);
               
            }
                rs.close();
                stmt.close();
        }catch(SQLException ex){
            System.out.println("Erro no consultar do DAOVendaProduto. java "+ex);
          
            
        }
        
        
        return listaVendaProduto;
    
}
     private int lastId;

    public int getLastId() {
        return lastId;
    }
    
  
    public String inserir(VendaProduto vendas){
        String mensagem="";
        String sql ="insert into vendaproduto(idEvento,dataVenda,idCliente) values(?,?,?)";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, vendas.getIdEvento().getId());
            stmt.setDate(2, converte.converteBanco(vendas.getDataVenda()));
            stmt.setInt(3, vendas.getIdCliente().getId());
            
            
            
            if(stmt.executeUpdate()>0){
                ResultSet rs = stmt.getGeneratedKeys();
                mensagem = "VendaProduto cadastrado com sucesso";  
                if(rs.next()){
                    lastId=rs.getInt(1);
                }
            }else{
                mensagem = "VendaProduto não cadastrado";
            }
            stmt.close();
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
    
     public String alterar(VendaProduto vendas){
        String mensagem="";
        String sql ="update vendaproduto set idEvento=?,dataVenda=?,idCliente=? where id=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, vendas.getIdEvento().getId());
            stmt.setDate(2, converte.converteBanco(vendas.getDataVenda()));
            stmt.setInt(3, vendas.getIdCliente().getId()); 
            stmt.setInt(4, vendas.getId());
            
            if(stmt.executeUpdate()>0){
                mensagem = "VendaProduto alterado com sucesso";          
            }else{
                mensagem = "VendaProduto não alterado";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
     
     

*/
    
    
}
