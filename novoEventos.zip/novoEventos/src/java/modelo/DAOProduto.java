package modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class DAOProduto {
    
    
    
    
     public List<Produto> consultar(){
        String sql = "select * from produto";
        List<Produto> listaProduto = new ArrayList<>();
        
        try{
            
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            
            while(rs.next()){
                Produto produto = new Produto();
               
                 produto.setQtd(rs.getInt("qtd"));
                 produto.setPreco(rs.getDouble("preco"));
                 produto.setDescricao(rs.getString("descricao"));
                 produto.setId(rs.getInt("id"));
                 
                 
                listaProduto.add(produto);
               
            }
                rs.close();
                stmt.close();
        }catch(SQLException ex){
            System.out.println("Erro no consultar do DAOProduto. java "+ex);
            
        }
        
        
        return listaProduto;
    
}
    
    public String inserir(Produto produto){
        String mensagem="";
        String sql ="insert into produto(qtd,preco,descricao) values(?,?,?)";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, produto.getQtd());
            stmt.setDouble(2, produto.getPreco());
            stmt.setString(3, produto.getDescricao());
            
            
            
            if(stmt.executeUpdate()>0){
                mensagem = "Produto cadastrado com sucesso";          
            }else{
                mensagem = "Produto não cadastrado";
            }
            stmt.close();
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
    
     public String alterar(Produto produto){
        String mensagem="";
        String sql ="update produto set qtd=?,preco=?, descricao=? where id=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
             stmt.setInt(1, produto.getQtd());
            stmt.setDouble(2, produto.getPreco());
            stmt.setString(3, produto.getDescricao());
            stmt.setInt(4, produto.getId());
            
            if(stmt.executeUpdate()>0){
                mensagem = "Produto alterado com sucesso";          
            }else{
                mensagem = "Produto não alterado";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
     
      public String excluir(Produto produto){
        String mensagem="";
        String sql ="delete from produto where id=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, produto.getId());
            if(stmt.executeUpdate()>0){
                mensagem = "Produto excluido com sucesso";          
            }else{
                mensagem = "Produto não excluido";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
    
      
       public Produto localizar(Integer id){
        String sql="select * from produto where id=?";
        Produto produto = new Produto();
           try{
               PreparedStatement pst = Conexao.getPreparedStatement(sql);
               pst.setInt(1, id);
               ResultSet rs = pst.executeQuery();
               while(rs.next()){
                
                  produto.setQtd(rs.getInt("qtd"));
                 produto.setPreco(rs.getDouble("preco"));
                 produto.setDescricao(rs.getString("descricao"));
                 produto.setId(rs.getInt("id"));
                 
                   return produto;
           }
    } catch(SQLException erro){
               System.out.println("Erro no localizar do DAOProduto"+ erro.getMessage() + "\n Comando sql = " + sql);
    }
    
    return null;
    
}
    
}
