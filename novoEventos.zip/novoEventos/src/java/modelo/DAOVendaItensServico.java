package modelo;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class DAOVendaItensServico {
  
    
    
    DAOVendaServico daoV = new DAOVendaServico();
    DAOServico daoP = new DAOServico();
   ConverteData converte = new ConverteData();
   
    public List<VendaItensServico> getLista(Integer id){
        String sql = "select * from vendaitensservico where vendaServico=?";
        List<VendaItensServico> lista = new ArrayList<>();
        try{
            PreparedStatement pst = Conexao.getPreparedStatement(sql);
            pst.setInt(1, id);
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
              VendaItensServico vendaitensservico = new VendaItensServico();
               
                 vendaitensservico.setVendaServico(daoV.localizar(rs.getInt("vendaServico")));
                 vendaitensservico.setValor(rs.getDouble("valor"));
                 vendaitensservico.setQtd(rs.getInt("qtd"));
                 vendaitensservico.setIdServico(daoP.localizar(rs.getInt("idServico")));
                 vendaitensservico.setId(rs.getInt("id"));
                lista.add(vendaitensservico);
            }
            rs.close();
            pst.close();
        }catch(SQLException e){
            System.out.println("Erro de SQL DAO Itens Servico getLista(): "+e.getMessage());
        }
        return lista;
    }
    
  /*   public List<VendaItensServico> consultar(){
        String sql = "select * from vendaitensservico";
        List<VendaItensServico> listaItensVenda = new ArrayList<>();
        
        try{
            
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            ResultSet rs = stmt.executeQuery();
            
            
            while(rs.next()){
                VendaItensServico vendaitensservico = new VendaItensServico();
               
                 vendaitensservico.setVendaServico(daoV.localizar(rs.getInt("vendaServico")));
                 vendaitensservico.setValor(rs.getDouble("valor"));
                 vendaitensservico.setQtd(rs.getInt("qtd"));
                 vendaitensservico.setIdServico(daoP.localizar(rs.getInt("idServico")));
                 vendaitensservico.setId(rs.getInt("id"));
                 
                 
                listaItensVenda.add(vendaitensservico);
               
            }
                rs.close();
                stmt.close();
        }catch(SQLException ex){
            System.out.println("Erro no consultar do DAOItensVenda. java "+ex);
          
            
        }
        
        
        return listaItensVenda;
    
}
*/ 
    
  
    public String inserir(VendaItensServico vendaitensservico){
        String mensagem="";
        String sql ="insert into vendaitensservico(vendaServico,idServico,valor,qtd) values(?,?,?,?)";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, vendaitensservico.getVendaServico().getId());
            stmt.setInt(2, vendaitensservico.getIdServico().getId());
            stmt.setDouble(3, vendaitensservico.getValor());
            stmt.setInt(4, vendaitensservico.getQtd());
            
            
            
            
            
            if(stmt.executeUpdate()>0){
                mensagem = "ItensVenda cadastrado com sucesso";          
            }else{
                mensagem = "ItensVenda não cadastrado";
            }
            stmt.close();
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
    
     public String alterar(VendaItensServico vendaitensservico){
        String mensagem="";
        String sql ="update vendaitensservico set vendaServico=?,idServico=?,valor=?,qtd=? where id=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, vendaitensservico.getVendaServico().getId());
            stmt.setInt(2, vendaitensservico.getIdServico().getId());
            stmt.setDouble(3, vendaitensservico.getValor());
            stmt.setInt(4, vendaitensservico.getQtd());
            stmt.setInt(5, vendaitensservico.getId());
            
            if(stmt.executeUpdate()>0){
                mensagem = "ItensVenda alterado com sucesso";          
            }else{
                mensagem = "ItensVenda não alterado";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
     
      public String excluir(VendaItensServico vendaitensservico){
        String mensagem="";
        String sql ="delete from vendaitensservico where id=?";
        try{
            PreparedStatement stmt = Conexao.getPreparedStatement(sql);
            stmt.setInt(1, vendaitensservico.getId());
            if(stmt.executeUpdate()>0){
                mensagem = "ItensVenda excluido com sucesso";          
            }else{
                mensagem = "ItensVenda não excluido";
            }
            stmt.close(); //fecha a conexão
        }catch(SQLException erro){
            mensagem = erro.getMessage()+"\nComando SQL = "+sql;
        }
       
        return mensagem;
    }
    
    
}
